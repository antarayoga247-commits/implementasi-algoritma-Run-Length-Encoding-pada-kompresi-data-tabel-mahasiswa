# src/utils.py

import json
import os

DATA_FILE = os.path.join('data', 'attendance.json')

def load_data():
    """
    Memuat data absensi dari file JSON.
    Jika file tidak ada, kembalikan struktur data kosong.
    """
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    if not os.path.exists(DATA_FILE):
        return {"students": {}, "dates": []}
    
    try:
        with open(DATA_FILE, 'r') as f:
            # Pastikan file tidak kosong
            content = f.read()
            if not content:
                return {"students": {}, "dates": []}
            return json.loads(content)
    except (json.JSONDecodeError, FileNotFoundError):
        return {"students": {}, "dates": []}

def save_data(data):
    """Menyimpan data (dictionary) ke file JSON."""
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)