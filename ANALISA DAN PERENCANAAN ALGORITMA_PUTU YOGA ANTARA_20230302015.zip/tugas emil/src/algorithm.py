# src/algorithm.py

def compress_rle(data_string: str):
    """
    Mengompres string menggunakan Run-Length Encoding (RLE).
    Contoh: "hhsssaai" -> [('h', 2), ('s', 3), ('a', 2), ('i', 1)]
    """
    if not data_string:
        return []
    
    compressed_data = []
    count = 1
    # Mulai dari elemen kedua karena kita membandingkan dengan sebelumnya
    for i in range(1, len(data_string)):
        if data_string[i] == data_string[i-1]:
            count += 1
        else:
            compressed_data.append((data_string[i-1], count))
            count = 1
    
    # Tambahkan elemen terakhir
    compressed_data.append((data_string[-1], count))
    
    return compressed_data

def decompress_rle(compressed_data: list):
    """
    Mendekompres data RLE kembali ke string.
    Contoh: [('h', 2), ('s', 3), ('a', 2), ('i', 1)] -> "hhsssaai"
    """
    if not compressed_data:
        return ""
    return "".join([char * count for char, count in compressed_data])

def format_compressed_data(compressed_data: list):
    """
    Mengubah format data terkompres menjadi string yang bisa dibaca.
    Contoh: [('h', 2), ('s', 3), ('a', 2), ('i', 1)] -> "h2s3a2i1"
    """
    # Mengubah urutan 'count' dan 'char' agar karakter dahulu baru hitungan
    return "".join([f"{char}{count}" for char, count in compressed_data])