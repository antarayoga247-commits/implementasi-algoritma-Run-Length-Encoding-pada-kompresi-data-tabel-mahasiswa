# src/main.py

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, Toplevel, scrolledtext
import tkinter.font as tkFont # Import for font customization

from utils import load_data, save_data
from algorithm import compress_rle, decompress_rle, format_compressed_data
import datetime
import os # Import os for file operations
from collections import Counter # Import Counter for easy counting

# Fungsi migrasi data tidak berubah, kita tetap membutuhkannya
def migrate_data_if_needed(data):
    if not data or not data.get('students'):
        return data, False
    if not data['students']:
        return data, False

    # Check for old 'dates' key (dynamic date-based system)
    if 'dates' in data and data['dates']:
        print("Mendeteksi format data berbasis tanggal lama.")
        if messagebox.askyesno("Migrasi Data Lama", 
                               "Sistem absensi sekarang menggunakan 14 slot pertemuan tetap.\n" 
                               "Data absensi lama Anda akan diinisialisasi ulang menjadi 14x 'h' (hadir) " 
                               "untuk setiap siswa.\n" 
                               "Apakah Anda ingin melanjutkan migrasi?"):
            
            # Reset 'meetings' to 14 fixed slots
            data['meetings'] = [f"P{i+1}" for i in range(14)]
            # Convert student data
            new_students_data = {}
            for nim_or_name, student_info in data['students'].items():
                if isinstance(student_info, str): # Oldest format (name: attendance_string)
                    name = nim_or_name
                    current_nim = str(len(new_students_data) + 1) # Generate a dummy NIM
                    new_students_data[current_nim] = {
                        "name": name,
                        "attendance": 'h' * 14 # Reset to 14 'h's
                    }
                    print(f"Migrasi siswa '{name}': NIM otomatis {current_nim}, absensi reset ke 14x 'h'.")
                else: # Old format (nim: {name: "", attendance: ""}) but with old attendance length
                    nim = nim_or_name
                    new_students_data[nim] = {
                        "name": student_info.get("name", "Unknown"),
                        "attendance": 'h' * 14 # Reset to 14 'h's
                    }
                    print(f"Migrasi siswa '{student_info.get('name', 'Unknown')}' (NIM: {nim}): absensi reset ke 14x 'h'.")
            data['students'] = new_students_data
            del data['dates'] # Remove old dates
            print("Migrasi data selesai.")
            return data, True
        else:
            messagebox.showwarning("Migrasi Dibatalkan", "Migrasi dibatalkan. Aplikasi akan menggunakan data default atau kosong.")
            return {"students": {}, "meetings": [f"P{i+1}" for i in range(14)]}, True # Return clean new structure
    
    # Check for old 'students' structure without NIM in new system
    first_key = next(iter(data['students']))
    if isinstance(data['students'][first_key], str):
        print("Mendeteksi format data lama (tanpa NIM di objek siswa). Melakukan migrasi...")
        new_students_data = {}
        nim_counter = 1
        for name, attendance_string in data['students'].items():
            new_nim = str(nim_counter)
            new_students_data[new_nim] = {
                "name": name,
                "attendance": 'h' * 14 # Ensure 14 length
            }
            nim_counter += 1
        data['students'] = new_students_data
        if 'dates' in data: del data['dates'] # Remove old dates
        if 'meetings' not in data:
             data['meetings'] = [f"P{i+1}" for i in range(14)]
        print("Migrasi data selesai.")
        return data, True

    # Ensure 'meetings' key exists and has 14 entries
    if 'meetings' not in data or len(data['meetings']) != 14:
        print("Menginisialisasi daftar pertemuan (14x).")
        data['meetings'] = [f"P{i+1}" for i in range(14)]
        # Ensure all existing students have 14 attendance records
        for nim in data['students']:
            if len(data['students'][nim]['attendance']) != 14:
                data['students'][nim]['attendance'] = data['students'][nim]['attendance'].ljust(14, 'h') # Pad with 'h'
        return data, True

    return data, False

class AttendanceApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Aplikasi Absensi Siswa (14 Pertemuan RLE)")
        self.geometry("900x600")

        self.data = load_data()
        data, changed = migrate_data_if_needed(self.data)
        if changed:
            self.data = data
            save_data(self.data)
        
        # Ensure meetings are always initialized if data was empty initially
        if 'meetings' not in self.data or len(self.data['meetings']) != 14:
            self.data['meetings'] = [f"P{i+1}" for i in range(14)]
            save_data(self.data)
            
        self.style = ttk.Style(self) # Initialize style
        self._setup_styles() # Setup custom styles
        
        self.create_widgets()
        self.populate_attendance_table()
        
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def _setup_styles(self):
        self.style.theme_use('clam') # Use 'clam' theme as a base

        # Define colors
        self.bg_primary = "#f0f0f0" # Light gray
        self.bg_secondary = "#ffffff" # White
        self.accent_blue = "#3498db" # Moderate blue
        self.accent_light_blue = "#a0d9f7" # Lighter blue
        self.text_dark = "#333333" # Dark gray for text

        # General App Styling
        self.configure(bg=self.bg_primary)
        self.style.configure('.', font=('Segoe UI', 10), background=self.bg_primary, foreground=self.text_dark)
        
        # Frame Styling
        self.style.configure('TFrame', background=self.bg_primary)

        # Button Styling
        self.style.configure('TButton',
                             font=('Segoe UI', 10, 'bold'),
                             background=self.accent_blue,
                             foreground=self.bg_secondary,
                             padding=5,
                             relief='flat')
        self.style.map('TButton',
                       background=[('active', self.accent_light_blue), ('pressed', self.accent_blue)],
                       foreground=[('active', self.text_dark)])

        # Label Styling
        self.style.configure('TLabel', background=self.bg_primary, foreground=self.text_dark)
        self.style.configure('Title.TLabel', font=('Segoe UI', 12, 'bold'), foreground=self.accent_blue)

        # Entry Styling
        self.style.configure('TEntry', fieldbackground=self.bg_secondary, foreground=self.text_dark, borderwidth=1, relief='solid')

        # Treeview (Table) Styling
        self.style.configure('Treeview', 
                             background=self.bg_secondary,
                             foreground=self.text_dark,
                             rowheight=25,
                             fieldbackground=self.bg_secondary,
                             borderwidth=0)
        self.style.map('Treeview', 
                       background=[('selected', self.accent_light_blue)],
                       foreground=[('selected', self.text_dark)])
        
        self.style.configure('Treeview.Heading', 
                             font=('Segoe UI', 10, 'bold'), 
                             background=self.accent_blue, 
                             foreground=self.bg_secondary,
                             relief='flat')
        self.style.map('Treeview.Heading',
                       background=[('active', self.accent_light_blue)])

        # Alternating row colors tags will be configured on the treeview instance, not style object

    def create_widgets(self):
        main_frame = ttk.Frame(self, padding="10", style='TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True)

        control_frame = ttk.Frame(main_frame, style='TFrame')
        control_frame.pack(fill=tk.X, pady=10)

        ttk.Button(control_frame, text="Tambah Siswa Baru", command=self.open_add_student_window, style='TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Hapus Siswa", command=self.delete_selected_student, style='TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Lihat Data Kompresi", command=self.open_compressed_data_window, style='TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Refresh Data", command=self.refresh_table, style='TButton').pack(side=tk.LEFT, padx=5)

        ttk.Label(main_frame, text="Tabel Absensi Siswa", style='Title.TLabel').pack(pady=5)

        table_frame = ttk.Frame(main_frame, style='TFrame')
        table_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        scroll_y = ttk.Scrollbar(table_frame, orient=tk.VERTICAL)
        scroll_x = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL)

        self.tree = ttk.Treeview(table_frame, yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set, show='headings', selectmode="browse", style='Treeview')
        self.tree.bind("<Button-1>", self.start_inline_edit)
        
        scroll_y.config(command=self.tree.yview)
        scroll_x.config(command=self.tree.xview)

        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)

        # Alternating row colors - CONFIGURED ON TREEVIEW INSTANCE
        # Define tags here because self.tree needs to exist
        self.tree_tag_odd_row = 'oddrow'
        self.tree_tag_even_row = 'evenrow'
        self.tree.tag_configure(self.tree_tag_odd_row, background='#f5f5f5')
        self.tree.tag_configure(self.tree_tag_even_row, background=self.bg_secondary)

        self.inline_editor = None # Track the currently active Entry widget


    def populate_attendance_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        students_data = self.data.get('students', {})
        meetings = self.data.get('meetings', [])

        columns = ["NIM", "Nama Siswa"] + meetings
        self.tree["columns"] = columns
        
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=60, anchor='center')
        
        self.tree.column("NIM", width=80, anchor='center')
        self.tree.column("Nama Siswa", width=150, anchor='w')

        for i, nim in enumerate(sorted(students_data.keys())):
            student_info = students_data[nim]
            name = student_info.get('name', '')
            attendance = student_info.get('attendance', '')
            
            padded_attendance = attendance.ljust(14, 'h') 

            row_data = [nim, name] + list(padded_attendance)
            
            # Apply alternating row tags
            if i % 2 == 0:
                self.tree.insert("", "end", values=row_data, iid=nim, tags=(self.tree_tag_even_row,))
            else:
                self.tree.insert("", "end", values=row_data, iid=nim, tags=(self.tree_tag_odd_row,))

    def refresh_table(self):
        self.data = load_data()
        data, changed = migrate_data_if_needed(self.data)
        if changed:
            self.data = data
            save_data(self.data)
        self.populate_attendance_table()
        messagebox.showinfo("Refresh", "Data telah dimuat ulang dari file.")

    def delete_selected_student(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Peringatan", "Pilih siswa yang ingin dihapus dari tabel terlebih dahulu. Klik pada kolom NIM atau 'Nama Siswa' untuk memilih.")
            return

        nim = selected_item
        student_name = self.data['students'][nim]['name']
        
        if messagebox.askyesno("Konfirmasi Hapus", f"Apakah Anda yakin ingin menghapus siswa '{student_name}' (NIM: {nim})? Seluruh data absensinya akan hilang."):
            del self.data['students'][nim]
            save_data(self.data)
            self.populate_attendance_table()
            messagebox.showinfo("Sukses", "Siswa telah berhasil dihapus.")

    def start_inline_edit(self, event):
        if self.inline_editor:
            self._process_inline_edit(self.inline_editor)

        item_id = self.tree.identify_row(event.y)
        column_id = self.tree.identify_column(event.x)
        
        if not item_id:
            return
            
        if column_id in self.tree["columns"][:2]:
            self.tree.selection_set(item_id)
            return
        
        self.tree.selection_remove(self.tree.selection())

        column_index = int(column_id.replace('#', '')) - 1
        nim = item_id
        meeting_index = column_index - 2
        
        bbox = self.tree.bbox(item_id, column_id)
        if not bbox:
            return

        current_value = self.tree.set(item_id, column_id)

        self.inline_editor = ttk.Entry(self.tree, width=bbox[2], justify='center', style='TEntry')
        self.inline_editor.place(x=bbox[0], y=bbox[1], width=bbox[2], height=bbox[3])
        self.inline_editor.insert(0, current_value)
        self.inline_editor.focus_set()

        self.inline_editor.nim = nim
        self.inline_editor.meeting_index = meeting_index

        self.inline_editor.bind("<Return>", self._on_editor_return)
        self.inline_editor.bind("<FocusOut>", self._on_editor_focus_out)

    def _on_editor_return(self, event):
        self._process_inline_edit(event.widget)

    def _on_editor_focus_out(self, event):
        if event.widget == self.inline_editor:
            self._process_inline_edit(event.widget)

    def _process_inline_edit(self, editor_widget):
        if not editor_widget or not hasattr(editor_widget, 'nim'):
            return

        nim = editor_widget.nim
        meeting_index = editor_widget.meeting_index
        new_value = editor_widget.get().strip().lower()

        editor_widget.destroy()
        if self.inline_editor == editor_widget:
            self.inline_editor = None

        if new_value not in ['h', 's', 'i', 'a']:
            messagebox.showerror("Error", "Input tidak valid. Harap masukkan 'h', 's', 'i', atau 'a'.")
            self.populate_attendance_table()
            return

        current_att_string = self.data['students'][nim]['attendance'].ljust(14, 'h')
        att_list = list(current_att_string)
        att_list[meeting_index] = new_value
        self.data['students'][nim]['attendance'] = "".join(att_list)
        
        save_data(self.data)
        self.populate_attendance_table()

    def open_add_student_window(self):
        dialog = Toplevel(self)
        dialog.title("Tambah Siswa Baru")
        dialog.configure(bg=self.bg_primary)

        dialog_frame = ttk.Frame(dialog, padding="10", style='TFrame')
        dialog_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(dialog_frame, text="NIM:", style='TLabel').grid(row=0, column=0, padx=10, pady=5, sticky='w')
        nim_entry = ttk.Entry(dialog_frame, style='TEntry')
        nim_entry.grid(row=0, column=1, padx=10, pady=5)
        
        ttk.Label(dialog_frame, text="Nama:", style='TLabel').grid(row=1, column=0, padx=10, pady=5, sticky='w')
        name_entry = ttk.Entry(dialog_frame, style='TEntry')
        name_entry.grid(row=1, column=1, padx=10, pady=5)

        def save_student():
            nim = nim_entry.get().strip()
            name = name_entry.get().strip()
            if not nim or not name:
                messagebox.showerror("Error", "NIM dan Nama tidak boleh kosong.", parent=dialog)
                return
            if nim in self.data['students']:
                messagebox.showerror("Error", f"Siswa dengan NIM {nim} sudah ada.", parent=dialog)
                return
            
            self.data['students'][nim] = {"name": name, "attendance": 'h' * 14}
            save_data(self.data)
            self.populate_attendance_table()
            messagebox.showinfo("Sukses", f"Siswa '{name}' berhasil ditambahkan.", parent=dialog)
            dialog.destroy()

        save_button = ttk.Button(dialog_frame, text="Simpan", command=save_student, style='TButton')
        save_button.grid(row=2, column=0, columnspan=2, pady=10)
        dialog.transient(self)
        dialog.grab_set()
        self.wait_window(dialog)

    def open_compressed_data_window(self):
        dialog = Toplevel(self)
        dialog.title("Analisis Kompresi RLE")
        dialog.geometry("700x550") # Adjusted height for better spacing
        dialog.configure(bg=self.bg_primary)

        main_pane = ttk.PanedWindow(dialog, orient=tk.HORIZONTAL)
        main_pane.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # --- STUDENT LIST FRAME ---
        list_frame = ttk.Frame(main_pane, width=200, style='TFrame')
        main_pane.add(list_frame, weight=1)
        
        ttk.Label(list_frame, text="Pilih Siswa:", style='TLabel').pack(pady=5, padx=5, anchor='w')
        
        self.student_listbox = tk.Listbox(list_frame, 
                                          bg=self.bg_secondary, 
                                          fg=self.text_dark, 
                                          selectbackground=self.accent_light_blue, 
                                          selectforeground=self.text_dark,
                                          borderwidth=1, relief='solid',
                                          font=('Segoe UI', 10),
                                          exportselection=False)
        self.student_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=(0, 5))
        
        for nim in sorted(self.data['students'].keys()):
            name = self.data['students'][nim]['name']
            self.student_listbox.insert(tk.END, f"{name} ({nim})")
            
        self.student_listbox.bind("<<ListboxSelect>>", self.on_student_select_for_compression)

        # --- DETAIL AND ANALYSIS FRAME ---
        detail_frame = ttk.Frame(main_pane, style='TFrame')
        main_pane.add(detail_frame, weight=3)

        text_area_frame = ttk.Frame(detail_frame)
        text_area_frame.pack(fill=tk.BOTH, expand=True, padx=(10, 5), pady=5)

        self.compression_text_area = tk.Text(text_area_frame, 
                                             wrap=tk.WORD, 
                                             bg=self.bg_secondary, 
                                             fg=self.text_dark,
                                             borderwidth=1, relief='solid',
                                             font=('Segoe UI', 10),
                                             padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(text_area_frame, orient=tk.VERTICAL, command=self.compression_text_area.yview)
        self.compression_text_area.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.compression_text_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # --- DEFINE STYLING TAGS FOR THE TEXT WIDGET ---
        bold_font = tkFont.Font(family="Segoe UI", size=11, weight="bold")
        monospace_font = tkFont.Font(family="Courier New", size=10)
        
        self.compression_text_area.tag_configure('title', font=bold_font, foreground=self.accent_blue, spacing3=10)
        self.compression_text_area.tag_configure('header', font=bold_font, spacing3=5)
        self.compression_text_area.tag_configure('monospace', font=monospace_font, background='#eee')
        
        # Tags for coloring attendance characters
        self.compression_text_area.tag_configure('att_h', foreground='#27ae60') # Green for 'hadir'
        self.compression_text_area.tag_configure('att_s', foreground='#f39c12') # Orange for 'sakit'
        self.compression_text_area.tag_configure('att_i', foreground='#3498db') # Blue for 'izin'
        self.compression_text_area.tag_configure('att_a', foreground='#c0392b') # Red for 'alfa'
        
        self.compression_text_area.tag_configure('sub_header', foreground='#555', font=('Segoe UI', 9, 'italic'))
        self.compression_text_area.tag_configure('highlight', background=self.accent_light_blue, font=('Segoe UI', 10, 'bold'))
        self.compression_text_area.tag_configure('dimmed', foreground='#7f8c8d') # Gray for less important info

        self.compression_text_area.insert(tk.END, "Pilih seorang siswa dari daftar di sebelah kiri untuk melihat detail kompresi.")
        self.compression_text_area.config(state=tk.DISABLED)

        dialog.transient(self)
        dialog.grab_set()
        self.wait_window(dialog)

    def on_student_select_for_compression(self, event):
        selection_indices = self.student_listbox.curselection()
        if not selection_indices:
            return
            
        selected_index = selection_indices[0]
        selected_list_item = self.student_listbox.get(selected_index)
        nim = selected_list_item.split('(')[-1].replace(')', '').strip()

        student = self.data['students'][nim]
        name = student['name']
        att_string = student['attendance'].ljust(14, 'h') 
        
        # --- PREPARE DATA ---
        compressed = compress_rle(att_string)
        formatted = format_compressed_data(compressed)
        decompressed = decompress_rle(compressed)

        original_size = len(att_string)
        compressed_size = len(formatted)
        try:
            ratio = (1 - (compressed_size / original_size)) * 100
        except ZeroDivisionError:
            ratio = 0

        status_counts = Counter(att_string)
        
        # --- BUILD THE REPORT IN THE TEXT WIDGET ---
        text_area = self.compression_text_area
        text_area.config(state=tk.NORMAL)
        text_area.delete(1.0, tk.END)

        # Title
        text_area.insert(tk.END, f"Analisis untuk: {name} (NIM: {nim})\n", 'title')

        if not att_string:
            text_area.insert(tk.END, "\n(Belum ada data absensi untuk dianalisis.)", 'dimmed')
            text_area.config(state=tk.DISABLED)
            return

        # 1. Original Data
        text_area.insert(tk.END, "\n1. Data Asli ", 'header')
        text_area.insert(tk.END, f"({original_size} karakter)\n", 'dimmed')
        # Insert character by character without specific color tags
        for char in att_string:
            text_area.insert(tk.END, char, 'monospace')
        text_area.insert(tk.END, "\n\n")

        # 2. Compressed Data (Python List)
        text_area.insert(tk.END, "2. Hasil Kompresi (Python List)\n", 'header')
        text_area.insert(tk.END, str(compressed), 'monospace')
        text_area.insert(tk.END, "\n\n")

        # 3. Formatted RLE String
        text_area.insert(tk.END, f"3. Hasil Kompresi (Format RLE - {compressed_size} karakter)\n", 'header')
        text_area.insert(tk.END, formatted, 'monospace')
        text_area.insert(tk.END, "\n\n")

        # 4. Decompressed Verification
        text_area.insert(tk.END, "4. Verifikasi Dekompresi\n", 'header')
        is_match = " (Cocok)" if decompressed == att_string else " (Tidak Cocok!)"
        text_area.insert(tk.END, decompressed)
        text_area.insert(tk.END, is_match, 'highlight' if is_match == " (Cocok)" else None) # Remove 'att_a' for non-match
        text_area.insert(tk.END, "\n\n")

        # 5. Size Analysis
        text_area.insert(tk.END, "5. Analisis Ukuran\n", 'header')
        text_area.insert(tk.END, f"   - Ukuran Asli: \t\t{original_size} karakter\n")
        text_area.insert(tk.END, f"   - Ukuran Kompresi: \t{compressed_size} karakter\n")
        text_area.insert(tk.END, f"   - Rasio Kompresi: \t", 'header')
        text_area.insert(tk.END, f"{ratio:.2f}%\n\n", 'highlight')
        
        # 6. Attendance Summary
        text_area.insert(tk.END, "6. Rekapitulasi Status\n", 'header')
        text_area.insert(tk.END, f"   - Hadir (h): \t\t{status_counts.get('h', 0)}\n")
        text_area.insert(tk.END, f"   - Sakit (s): \t\t{status_counts.get('s', 0)}\n")
        text_area.insert(tk.END, f"   - Izin  (i): \t\t{status_counts.get('i', 0)}\n")
        text_area.insert(tk.END, f"   - Alfa  (a): \t\t{status_counts.get('a', 0)}\n")

        text_area.config(state=tk.DISABLED)

        # --- SAVE TO FILE (UNCHANGED) ---
        analysis_filepath = os.path.join('docs', 'analysis_results.txt')
        os.makedirs(os.path.dirname(analysis_filepath), exist_ok=True)
        # We can create a simpler text report for the file
        file_report = self._create_text_report_for_file(name, nim, att_string, compressed, formatted, decompressed, original_size, compressed_size, ratio, status_counts)
        with open(analysis_filepath, 'a') as f:
            f.write("="*50 + "\n")
            f.write(f"Analisis RLE ({datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
            f.write("="*50 + "\n")
            f.write(file_report + "\n\n")

    def _create_text_report_for_file(self, name, nim, att_string, compressed, formatted, decompressed, original_size, compressed_size, ratio, status_counts):
        """Helper to generate a plain text report for saving to a file."""
        report = f"Analisis untuk: {name} (NIM: {nim})\n"
        report += "-"*40 + "\n"
        report += f"1. Data Asli ({original_size} karakter):\n{att_string}\n\n"
        report += f"2. Hasil Kompresi (Python List):\n{compressed}\n\n"
        report += f"3. Hasil Kompresi (Format RLE String - {compressed_size} karakter):\n{formatted}\n\n"
        report += f"4. Verifikasi Dekompresi:\n{decompressed}\n\n"
        report += f"5. Analisis Ukuran:\n"
        report += f"   - Ukuran Asli: {original_size} karakter\n"
        report += f"   - Ukuran Setelah Kompresi: {compressed_size} karakter\n"
        report += f"   - Rasio Kompresi: {ratio:.2f}%\n\n"
        report += "6. Rekapitulasi Status Absensi:\n"
        report += f"   - Hadir (h): {status_counts.get('h', 0)}\n"
        report += f"   - Sakit (s): {status_counts.get('s', 0)}\n"
        report += f"   - Izin  (i): {status_counts.get('i', 0)}\n"
        report += f"   - Alfa  (a): {status_counts.get('a', 0)}\n"
        return report



    def on_closing(self):
        if self.inline_editor:
            self._process_inline_edit(self.inline_editor)
        save_data(self.data)
        self.destroy()

if __name__ == "__main__":
    app = AttendanceApp()
    app.mainloop()
