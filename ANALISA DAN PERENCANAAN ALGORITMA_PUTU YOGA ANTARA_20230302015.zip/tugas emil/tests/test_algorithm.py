# tests/test_algorithm.py

import unittest
import sys
import os

# Tambahkan direktori src ke path untuk impor
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from algorithm import compress_rle, decompress_rle, format_compressed_data

class TestRLEAlgorithm(unittest.TestCase):
    """Kumpulan tes untuk algoritma RLE."""

    def test_compression(self):
        """Tes fungsionalitas kompresi RLE."""
        self.assertEqual(compress_rle("hhsssaai"), [('h', 2), ('s', 3), ('a', 2), ('i', 1)])
        self.assertEqual(compress_rle("aaaaa"), [('a', 5)])
        self.assertEqual(compress_rle("siasia"), [('s', 1), ('i', 1), ('a', 1), ('s', 1), ('i', 1), ('a', 1)])
        self.assertEqual(compress_rle(""), [])
        self.assertEqual(compress_rle("s"), [('s', 1)])

    def test_decompression(self):
        """Tes fungsionalitas dekompresi RLE."""
        self.assertEqual(decompress_rle([('h', 2), ('s', 3), ('a', 2), ('i', 1)]), "hhsssaai")
        self.assertEqual(decompress_rle([('a', 5)]), "aaaaa")
        self.assertEqual(decompress_rle([('s', 1), ('i', 1), ('a', 1), ('s', 1), ('i', 1), ('a', 1)]), "siasia")
        self.assertEqual(decompress_rle([]), "")
        self.assertEqual(decompress_rle([('s', 1)]), "s")

    def test_round_trip(self):
        """Tes round-trip: kompresi -> dekompresi harus menghasilkan data asli."""
        original_strings = ["hhsssaai", "aaaaa", "siasia", "s", ""]
        for s in original_strings:
            with self.subTest(s=s):
                compressed = compress_rle(s)
                decompressed = decompress_rle(compressed)
                self.assertEqual(s, decompressed)
    
    def test_format_compressed(self):
        """Tes pemformatan string kompresi."""
        # Mengubah expected value agar sesuai dengan format baru "char kemudian count"
        self.assertEqual(format_compressed_data([('h', 2), ('s', 3), ('a', 2), ('i', 1)]), "h2s3a2i1")
        self.assertEqual(format_compressed_data([('a', 10)]), "a10")
        self.assertEqual(format_compressed_data([]), "")

if __name__ == '__main__':
    unittest.main(verbosity=2)
